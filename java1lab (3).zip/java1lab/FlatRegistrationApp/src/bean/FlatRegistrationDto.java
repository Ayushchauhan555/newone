package bean;

public class FlatRegistrationDto {

	private int registrationId;
	private int flatType;
	private int squareFeet;
	private int rentAmount;
	private int depositAmount;
	private int flatOwnerId;


	public FlatRegistrationDto() {
		super();
	}

	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	public int getFlatType() {
		return flatType;
	}
	public void setFlatType(int flatType) {
		this.flatType = flatType;
	}
	public int getSquareFeet() {
		return squareFeet;
	}
	public void setSquareFeet(int squareFeet) {
		this.squareFeet = squareFeet;
	}
	public int getRentAmount() {
		return rentAmount;
	}
	public void setRentAmount(int rentAmount) {
		this.rentAmount = rentAmount;
	}
	public int getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(int depositAmount) {
		this.depositAmount = depositAmount;
	}


	public int getFlatOwnerId() {
		return flatOwnerId;
	}

	public void setFlatOwnerId(int flatOwnerId) {
		this.flatOwnerId = flatOwnerId;
	}

	public FlatRegistrationDto(int registrationId, int flatType, int squareFeet, int rentAmount, int depositAmount, int flatOwnerId) {
		super();
		this.registrationId = registrationId;
		this.flatType = flatType;
		this.squareFeet = squareFeet;
		this.rentAmount = rentAmount;
		this.depositAmount = depositAmount;
		this.flatOwnerId = flatOwnerId;
	}




}

