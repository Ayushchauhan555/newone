package com.capgemini.hotel.ui;

import java.util.Scanner;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.exceptions.AccountIdNotFound;
import com.capgemini.hotel.exceptions.UserInputValidation;
import com.capgemini.hotel.service.HotelService;
import com.capgemini.hotel.service.IHotelService;

public class Client {
	

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
	//	RoomBooking roomBook = new RoomBooking();
		
		
		IHotelService hotelService = new HotelService();
		
		
		String cName;
		String cEmail;
		String cAddress;
		String cMobileNo;
		String rRoomNo;
		String rRoomType;
		
		while(true) {
			CustomerBean account = new CustomerBean();
			System.out.println("1) Book Room\n2) View Booking Details\n3) Exit");
			String dashBoardIp = sc.nextLine();
			switch(dashBoardIp) {
				case "1":
					
					while(true) {
						System.out.print("Enter Customer Name :");
						cName = sc.nextLine();
						System.out.print("Enter Email:");
						cEmail = sc.nextLine();
						System.out.print("Enter Customer Address:");
						cAddress = sc.nextLine();
						System.out.print("Enter Mobile No :");
						cMobileNo = sc.nextLine();
						System.out.println("Room No:");
						rRoomNo = sc.nextLine();
						System.out.println("Room Type:");
						rRoomType = sc.nextLine();
						try {
							hotelService.Validation(rRoomNo, cName, cEmail, rRoomType);
							break;
						}
						catch(UserInputValidation u) {
							System.out.println(u.getMessage());	
						}
					}
					
					
					
					account.setName(cName);
					account.setAddress(cAddress);
					account.setEmail(cEmail);
					account.setMobileNo(cMobileNo);

					
					int id = hotelService.addCustomerDetails(account);
					System.out.println("Your Room has been successfully booked , your Customer ID is "+id);
					
					hotelService.roomInfo(rRoomType, Integer.parseInt(rRoomNo),account);

					break;
				case "2":
					System.out.print("Enter Customer ID :");
					String cID = sc.nextLine();
					while(true) {				
						try {
							hotelService.accountIdValidation(cID);
							break;
						}
						catch(AccountIdNotFound e) {
							System.out.println(e.getMessage());
							System.out.println("Enter again[print 'exit' for exit]");
							cID = sc.nextLine();
							if(cID.equals("exit")) {
								break;
							}
						}
					}
					if(cID.equals("exit")) {
						break;
					}
					RoomBooking roomInfo = (RoomBooking) hotelService.getBookingDetails(Integer.parseInt(cID));
					System.out.println("Name of the Customer:  "+roomInfo.getCustomer().getName());
					System.out.println("Room No :"+roomInfo.getRoomNo());
					System.out.println("Room Type :"+roomInfo.getRoomType());
					break;
				case "3":
					System.out.println("thank you");
					System.exit(1);
				default:
					System.out.println("invalid input");
			}
		}
		
		
		
		
		
		
		
	}
}
