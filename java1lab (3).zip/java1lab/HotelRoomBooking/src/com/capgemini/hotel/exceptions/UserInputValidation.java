package com.capgemini.hotel.exceptions;

public class UserInputValidation extends RuntimeException{
	public UserInputValidation(String message) {
		super(message);
	}
}
