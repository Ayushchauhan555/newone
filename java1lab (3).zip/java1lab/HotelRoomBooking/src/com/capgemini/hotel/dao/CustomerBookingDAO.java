package com.capgemini.hotel.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;

public class CustomerBookingDAO implements ICustomerBookingDAO {
	
	Map<Integer,CustomerBean> customerDetails = new HashMap<Integer,CustomerBean>();
	Map<Integer,RoomBooking> roomBooking = new HashMap<Integer,RoomBooking>();
	
	
	
	@Override
	public int addCustomerDetails(CustomerBean bean) {
		customerDetails.put(bean.getCustomerId(), bean);
		//rm.setCustomerId(bean.getCustomerId());
	//	rm.setCustomer(bean);
		//System.out.println(customer);
		System.out.println("before adding into room booking"+roomBooking);
		return bean.getCustomerId();
		
	}
	

	@Override
	public RoomBooking getBookingDetails(int CustomerId) {
//		System.out.println(CustomerId);
//		System.out.println(roomBooking);
//		RoomBooking b = (RoomBooking) roomBooking.get(CustomerId);
//		System.out.println(b.getRoomNo());
		return roomBooking.get(CustomerId);
	}

	@Override
	public boolean accountIdValidation(int customerId) {
		// TODO Auto-generated method stub
		
		if(roomBooking.containsKey(customerId)) {
			return true;
		}
		return false;
	}


	@Override
	public void roomInfo(RoomBooking roomBean) {
		// TODO Auto-generated method stub
		System.out.println("before "+roomBooking);
		roomBooking.put(roomBean.getCustomerId(), roomBean);
		System.out.println("after "+roomBooking);
	}

}
