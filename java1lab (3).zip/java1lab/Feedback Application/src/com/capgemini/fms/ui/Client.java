package com.capgemini.fms.ui;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.fms.ExceptionClass.AlreadyGiveFeedback;
import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.service.FeedbackService;

public class Client {
public static void main(String[] args) throws AlreadyGiveFeedback 
{	
	FeedbackService fdBack=new FeedbackService();
	Scanner sc=new Scanner(System.in);
	int choice;
	System.out.println("Feedback Portal\nEnter 1 for Feedback\nEnter 2 for Print Feedback Report\nEnter 3 for Exit");
	choice=sc.nextInt();
	while(true)		// Menu for user to perform operations
	{
		switch(choice)
		{
			case 1:// taking input from userb
				try
				{
				System.out.println("Enter your Teacher Name");
				String TName=sc.next();				//Entering the teacher name
				System.out.println("Enter your Subject name");
				String subject=sc.next();			//Entering the subject name 
				System.out.println("Enter your Rating");
				int rating=sc.nextInt();				//Entering the rating
				Map<String, Integer> map=fdBack.addFeedbackDetails(TName, rating, subject);
				if(!map.isEmpty())
				{
				System.out.println("added succesfully");
				Set set= map.entrySet(); // Get a set of the entries
				Iterator i= set.iterator(); // Get an iterator
				while(i.hasNext()) { // Display elements
				Map.Entry me = (Map.Entry)i.next();
				System.out.println(me.getKey() + ": "+ me.getValue());
				}
				}
				}
				catch(Exception e)
				{
					System.out.println("Try again");
				}
				break;
		case 2:
			Map m=fdBack.getFeedbackReport();
			Set set= m.entrySet(); // Get a set of the entries
			Iterator i= set.iterator(); // Get an iterator
			while(i.hasNext()) { // Display elements
			Map.Entry me = (Map.Entry)i.next();
			System.out.println(me.getKey() + ": "+ me.getValue());
			}
			break;
		case 3://exit the program
			System.out.println("thnks for your feedback");
			System.exit(0);
			
			default:
				System.out.println("Invalid Input");
	
	}
		System.out.println("Feedback Portal\nEnter 1 for Feedback\nEnter 2 for Print Feedback Report\nEnter 3 for Exit");
		choice=sc.nextInt();
}
}
}