package com.capgemini.fms.service;

import java.util.Scanner;

public class Validation 
{
	//check the valid subject or not
	public String checkSubjectName(String Subject)
	{
		Scanner sc=new Scanner(System.in);
		while(true) 
		{
			if((Subject.equals("Math")||Subject.equals("math")||(Subject.equals("English")||Subject.equals("english"))))
			{
				return Subject;
			}
			else 
			{
				System.out.println("Subject should either english or math");
				System.out.println("Enter again: ");
				Subject = sc.next();
			}
		}
	}
	//validate the rating
	public int checkRating(int rating) 
	{
		Scanner sc=new Scanner(System.in);
		while(true) 
		{
			if(rating<6 && rating>0)
			{
				return rating;
			}
			else 
			{
				System.out.println("rating should not be greater then 5");
				System.out.println("Enter again: ");
				rating = sc.nextInt();
			}
		}	
		
	}
}
