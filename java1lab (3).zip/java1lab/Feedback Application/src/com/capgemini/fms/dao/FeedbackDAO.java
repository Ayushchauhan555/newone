package com.capgemini.fms.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.capgemini.fms.ExceptionClass.AlreadyGiveFeedback;

public class FeedbackDAO implements IFeedbackDAo {
	Map<String, Integer> MathFeedBackMap=new HashMap<>();// map to store math feed back
	Map<String, Integer> EnglishFeedBackMap=new HashMap<>();//map to store english feed back
//	method to store values in map
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) throws AlreadyGiveFeedback 
	{	
		if(subject.equals("Math")||subject.equals("math"))
		{	
			if(MathFeedBackMap.isEmpty())
			{	
				MathFeedBackMap.put(name,rating);
				return MathFeedBackMap;
			}
			else if(MathFeedBackMap.containsKey(name))
			{
				throw new AlreadyGiveFeedback("Already give the feedBack");
			}
			else
			{
				MathFeedBackMap.put(name,rating);
				return MathFeedBackMap;
			}
		}
		if(subject.equals("English")||subject.equals("english"))
		{
			if(EnglishFeedBackMap.isEmpty())
			{
				EnglishFeedBackMap.put(name,rating);
				System.out.println(EnglishFeedBackMap.get(name));
				return EnglishFeedBackMap;
			}
			else if(MathFeedBackMap.containsKey(name))
			{
				throw new AlreadyGiveFeedback("Already give the feedBack");
			}
			else
			{
				EnglishFeedBackMap.put(name,rating);
				return EnglishFeedBackMap;
			}
		}
		return null;
	}
	// method compare two hashmap and store the unique values with greater rating in new map and return it
	public Map<String, Integer> getFeedbackReport()	   
	{	
		HashMap<String,Integer> m;
		if(EnglishFeedBackMap.isEmpty()&& MathFeedBackMap.isEmpty())
		{
		return null;
		}
		else
		{
			 m=(HashMap<String, Integer>) EnglishFeedBackMap;
		Set set=MathFeedBackMap.entrySet();
		Iterator i= set.iterator();
		while(i.hasNext())
		{
			Entry<String, Integer> next = (Entry<String, Integer>) i.next();
			Map.Entry<String,Integer> me=next;
			if(m.containsKey(me.getKey()))
			{
				if(m.get(me.getKey())<me.getValue())
				m.put(me.getKey(),me.getValue());
			}
			else
				m.put(me.getKey(), me.getValue());
	
		}
		}
		return m;
}
}